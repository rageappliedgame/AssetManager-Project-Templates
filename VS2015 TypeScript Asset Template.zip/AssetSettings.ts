/// <reference path="../RageAssetManager/ISettings.ts"/>
///
module AssetPackage {

    import ISettings = AssetPackage.ISettings;

    /// <summary>
    /// An asset settings.
    /// </summary>
    export class $safeprojectname$Settings implements ISettings {

        //! region Fields

        // private _value: number = 0;

        //! endregion Fields

        //! region Fields

        /// <summary>
        /// Initializes a new instance of the AssetSettings class.
        /// </summary>
        constructor() {
            // this._value = 42;
        }

        //! endregion Fields

        //! region Properties

        // Your properties go here.

        //public get Value(): string {
        //    return this._value;
        //}

        //public setValue(value: string) {
        //    this._value = balue;
        //}

        //! endregion Properties
    }
}

