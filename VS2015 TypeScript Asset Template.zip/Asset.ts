/// <reference path="../RageAssetManager/AssetManager.ts"/>
/// <reference path="../RageAssetManager/BaseAsset.ts"/>
/// <reference path="../RageAssetManager/IAsset.ts"/>
/// <reference path="../RageAssetManager/IDataStorage.ts"/>
/// <reference path="../RageAssetManager/pubsubz.ts"/>
/// <reference path='../RageAssetManager/Dictionary.ts' />
/// <reference path="../$safeprojectname$/$safeprojectname$Settings.ts"/>
///
module AssetPackage {

    // Setup Aliases.
    import AssetManager = AssetManagerPackage.AssetManager;
    import Dictionary = AssetManagerPackage.Dictionary;
    import PubSubz = PubSubzPackage.PubSubz;
    import IAsset = AssetPackage.IAsset;
    import BaseAsset = AssetPackage.BaseAsset;
    import $safeprojectname$Settings = AssetPackage.$safeprojectname$Settings;

    /// <summary>
    /// Export the Asset.
    /// </summary>
    export class $safeprojectname$ extends BaseAsset {

	//! region Fields

        /// <summary>
        /// Information describing the protected version.
        /// </summary>
        ///
        /// <remarks>
        /// Commas after the last member and \r\n are not allowed.
        /// </remarks>
        protected versionInfo: string =
        '{ ' +
        '  "Major":"1", ' +
        '  "Minor":"2", ' +
        '  "Build":"3", ' +
        '  "Maturity":"Alpha"' + // ', ' +
        // '  "Dependencies": [ ' +
        // '        { ' +
        // '           "Class": "Logger", ' +
        // '           "minVersion": "1.2.4", ' +
        // '           "maxVersion": "1.*" ' +
        // '        } ' +
        // '   ] ' +
        '} ';

	//! endregion Fields

	//! region Constructors

        /// <summary>
        /// Initializes a new instance of the $safeprojectname$ class. Sets the ClassName property.
        /// </summary>
        constructor() {
            super();

            // Somehow Settings cannot be applied here (so must be set in the calling program).
            // this.Settings = new AssetSettings();
        }

        //! endregion Constructors

        //! region Methods

	//! Your code goes here.

        //! endregion Methods
    }
}